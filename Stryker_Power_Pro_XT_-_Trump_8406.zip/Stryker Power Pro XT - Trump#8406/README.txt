Stryker Power Pro XT - Trump#8406
------
High quality and accurate stretcher model that has been fully remodeled from scratch and integrated into GTA 5 multiplayer via a script. Walk up to the back of an ambulance to retrieve the stretcher, go pick up your patient, and put him into the back of the ambulance using this stretcher!

Stretcher Customization
     - Folding Seat
     - Backboard
     - Med Bag
     - Rush24 Backpack
     - LIFEPAK 15

Seating Positions*
     - Lay flat, sit on right side, sit on left side, sit on top

Compatibility*
     - Compatible with ALL ambulance models, just add a line to the config

*Features only avaiable with multiplayer script

------
For Singleplayer: Navigate to trump-stretcher\stream and extract vehicle file (assuming using a singleplayer stretcher script for AI or player)
For Multiplayer: Start the resources in the main folder
------
Current bugs: The person who spawns the stretcher is the only one who can move it; Medic B cannot pickup the stretcher if Medic A spawns it because it'll duplicate