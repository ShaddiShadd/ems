fx_version 'adamant'
game 'gta5'

client_scripts {
	'warmenu.lua',
	'config.lua',
  	'client/main.lua'
}
